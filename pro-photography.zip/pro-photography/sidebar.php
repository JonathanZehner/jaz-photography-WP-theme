<?php
    dynamic_sidebar('sidebar-widget');
?>